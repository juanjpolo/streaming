VitamioDemo
===========

The demo sample is a showcase of the functionality of Vitamio.

